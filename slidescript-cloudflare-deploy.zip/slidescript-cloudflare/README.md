# SlideScript — Cloudflare Pages deployment

This project serves the SlideScript interface from `index.html` and proxies Gemini requests through a Cloudflare Pages Function. The Gemini API key is **not** stored in the HTML or source control.

## Before deploying

1. Revoke the Gemini API key previously embedded in the old HTML, because it has been exposed in a client-side file.
2. Create a replacement key in Google AI Studio. Do not paste it into any project file.
3. Create a GitHub repository and upload the contents of this folder (not the folder wrapper) to the repository root. Keep `functions/` at the repository root and use `public/` as the static build output directory.
4. In Cloudflare Dashboard, open **Workers & Pages → Create application → Pages → Connect to Git** and connect the repository.
5. Select **None** for the framework preset. Set the build command to `exit 0` and the build output directory to `/` (root). Deploy.
6. In the Cloudflare Pages project, open **Settings → Variables and Secrets**. Add an **encrypted secret** named `GEMINI_API_KEY` with the replacement key. Save it, then redeploy the project.
7. Choose a project name such as `slidescript-tool`. If available, the site will be published at `https://slidescript-tool.pages.dev`.

Cloudflare's dashboard drag-and-drop Direct Upload does not currently compile a `functions/` directory. Use Git integration as described above, or deploy via Wrangler from the project folder.

## Local checks

The page supports `.pptx` uploads up to 500 MB. Each slide's extracted text and selected images are sent to Gemini via `/api/generate`. The function accepts only the two models configured in the interface, applies a request-size limit, caps output tokens, and reads the API key from Cloudflare's encrypted `GEMINI_API_KEY` secret.

## Important public-service note

Keeping the key server-side prevents visitors from reading it from the HTML, but a public `/api/generate` endpoint can still be called by others and may consume the project's Gemini free-tier quota. For a service used by more than you, add an access control or Turnstile/session check and/or Cloudflare rate limiting before public release. Keep billing disabled if you want to avoid paid API charges.
